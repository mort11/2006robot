/*******************************************************************************
* FILE NAME: autonomous.c
*
* DESCRIPTION:
* This file contains autonomous mode functions
*
*******************************************************************************/
#include <stdio.h>
#include "ifi_aliases.h"
#include "ifi_default.h"
#include "ifi_utilities.h"
#include "user_routines.h"
#include "camera.h"
#include "MORT_TRACKING.h"
#include "MORT_AUTONOMOUS.h"
#include "MORT_TIMERS.h"

/*************************************************************************************
                                   MORT VARIABLES                                  
*************************************************************************************/
int auton_state;
int first_run = 1;
extern int tracking_lock;
extern unsigned char Collector_Debounce;
extern unsigned char Gravity_Debounce;
extern unsigned char Shooter_Debounce;
extern unsigned char Manual_Toggle_State;
extern unsigned char Feed_Debounce;

extern long Timer1_Count;


int Get_Auto_Mode(void)
{
	if (rc_dig_in01 == 0)
		return 1;
	else if (rc_dig_in02 == 0)
		return 2;
	else if (rc_dig_in03 == 0)
		return 3;
	else if (rc_dig_in04 == 0)
		return 4;
	else if (rc_dig_in05 == 0)
		return 5;
	else if (rc_dig_in06 == 0)
		return 6;
	else
		return 0;
}

void MORT_autonomous_mode( int mode )
{

	switch (mode)
	{
		case JUST_SHOOT:
			just_shoot();
			break;

		case JUST_SHOOT_SET:
			if (first_run)
			{
				auton_state = SET_ALIGN_TURRET;
				first_run = 0;
			}
			just_shoot_set();
			break;

		case OUT_RIGHT_SHOOT:
			if (first_run)
			{
				auton_state = OUT_RESTART_CAMERA;
				first_run = 0;
			}
			out_right_shoot();
			break;
		
		case OUT_RIGHT_SHOOT_SET:
			if (first_run)
			{
				Timer1_Count = 0;
				auton_state = OUT_SET_MOVE_OUT_FROM_START;
				first_run = 0;
			}
			out_right_shoot_set();
			break;

		case DEFENSE:
			if (first_run)
			{
				Timer1_Count = 0;
				auton_state = DEFENSE_OUT;
				first_run = 0;
			}
			defense();
			break;

		default:
			turn_off_everything();
			break;
	}

}


//********************************************************************************************************
//							AUTONOMOUS MODE STATE MACHINE	
//********************************************************************************************************

void just_shoot(void)
{
	Camera_Handler();	// We always want to get new data from camera
	Turret_Track();
	
	Run_Ball_System();
	Run_Shooter_Wheel();
	Run_Shooter_Belt(25);

}

void just_shoot_set( void )
{
	Run_Ball_System();

	switch (auton_state)
	{
		case SET_ALIGN_TURRET:

			// Sacco balls is going to line up the robot pan by hand
			
			// 	Pull the tilt all the way back
			if (Get_Analog_Value(TURRET_TILT_POT) < TILT_POT_BACKWARD)
			{
				TURRET_TILT = TURRET_BACKWARD_MAX;			// Turret Forward
				printf("MOVING foward \r\n");
			}
			else
			{
				TURRET_TILT = 127;
				auton_state = SET_SHOOT_BALLS;
			}
		
			break;

		case SET_SHOOT_BALLS:

			Run_Shooter_Wheel();
			Run_Shooter_Belt(25);

			break;
	}	
}
			
void out_right_shoot( void )
{

	Camera_Handler();				// We always want the camera to have data
	Turret_Track();
	Run_Ball_System();

	switch (auton_state)
	{

		case OUT_INITIALIZE_CAMERA:

			if (Get_Camera_State())
			{
				Timer1_Count = 0;
				auton_state = OUT_MOVE_OUT_FROM_START;
			}
		
			break;

		case OUT_MOVE_OUT_FROM_START:

			p1_x = 127;
			p1_y = 212;


			if (Timer1_Count >= 55)
			{
				Timer1_Count = 0;
				auton_state = OUT_DELAY_FOR_TURN;
			}

			break;

		case OUT_DELAY_FOR_TURN:

			p1_x = 127;
			p1_y = 127;


			if (Timer1_Count >= 15)
			{	
				Timer1_Count = 0;
				auton_state = OUT_TURN_RIGHT;
			}

			break;

		case OUT_TURN_RIGHT:

			p1_x = 212;
			p1_y = 127;

			Run_Shooter_Wheel();

			if (Timer1_Count >= 15)
			{
				auton_state = OUT_SHOOT_BALLS;		//OUT_DELAY_FOR_APROACH;
			}

			break;

		case OUT_SHOOT_BALLS:

			p1_x = 127;
			p1_y = 127;

			Run_Shooter_Wheel();

			if (tracking_lock)
				Run_Shooter_Belt(8);
			
			break;
	}

}

void out_right_shoot_set( void )
{
	Run_Ball_System();

	switch (auton_state)
	{
		case OUT_SET_MOVE_OUT_FROM_START:

			p1_x = 127;
			p1_y = 212;

			if (Timer1_Count >= 55)
			{
				Timer1_Count = 0;
				auton_state = OUT_SET_DELAY_FOR_TURN;
			}

			break;

		case OUT_SET_DELAY_FOR_TURN:

			p1_x = 127;
			p1_y = 127;

			if (Timer1_Count >= 15)
			{	
				Timer1_Count = 0;
				auton_state = OUT_SET_TURN_RIGHT;
			}

			break;

		case OUT_SET_TURN_RIGHT:

			p1_x = 212;
			p1_y = 127;

			Run_Shooter_Wheel();

			if (Timer1_Count >= 15)
			{
				auton_state = OUT_SET_ALIGN_TURRET;
			}

			break;

		case OUT_SET_ALIGN_TURRET:
			p1_x = 127;
			p1_y = 127;

			Run_Shooter_Wheel();
			
			// 	Pull the tilt all the way back
			if (Get_Analog_Value(TURRET_TILT_POT) < TILT_POT_BACKWARD)
			{
				TURRET_TILT = TURRET_BACKWARD_MAX;			// Turret Forward
			}
			else
			{
				TURRET_TILT = 127;
			}

			// Center the pan
			if (Get_Analog_Value(TURRET_PAN_POT) > PAN_POT_CENTER + 7)
			{
				TURRET_PAN = TURRET_RIGHT_MAX;
			}
			else if (Get_Analog_Value(TURRET_PAN_POT) < PAN_POT_CENTER - 7)
			{
				TURRET_PAN = TURRET_LEFT_MAX;
			}
			else
			{
				TURRET_PAN = 127;
			}

			if (TURRET_TILT == 127 && TURRET_PAN == 127)
				auton_state = OUT_SET_SHOOT_BALLS;
			
			break;

		case OUT_SET_SHOOT_BALLS:

			p1_x = 127;
			p1_y = 127;

			Run_Shooter_Wheel();
			Run_Shooter_Belt(8);
			
			break;
	}

}

void defense( void )
{
	switch (auton_state)
	{
		case DEFENSE_OUT:
		
			p1_x = 127;
			p1_y = 212;
		
			if (Timer1_Count >= 55)
			{
				Timer1_Count = 0;
				auton_state = DEFENSE_RIGHT;
			}
			
			break;

		case DEFENSE_RIGHT:
			
			p1_x = 212;
			p1_y = 127;

			if (Timer1_Count >= 15)
			{
				Timer1_Count = 0;
				auton_state = DEFENSE_RIGHT;
			}
			
			break;

		case DEFENSE_STOP:

			p1_x = 127;
			p1_y = 127;

			break;
	}
}

void turn_off_everything( void )
{
	p1_x = 127;
	p1_y = 127;

	LEFT_WHEEL = 127;
	LEFT_WHEEL_2 = 127;

	RIGHT_WHEEL = 127;
	RIGHT_WHEEL_2 = 127;

	TURRET_PAN = 127;
	TURRET_TILT = 127;

	COLLECTOR = 127;

	SHOOTER_BELT = 127;
	SHOOTER_WHEEL = 127;
}	
