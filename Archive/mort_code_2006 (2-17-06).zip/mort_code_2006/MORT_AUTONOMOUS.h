/*******************************************************************************
* FILE NAME: MORT_AUTONOMOUS.h
*
* DESCRIPTION: 
*  This is the include file that defines all I/O used in the MORT 2005 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
*******************************************************************************/
#include "MORT_DEFINES.h"


// Defines for different autonomous modes
#define STRAIGHT_AND_RIGHT	1
#define MIDFIELD_DEFENSE	2
#define DIAGONAL_DEFENSE	3

// Define the states for STRAIGHT_AND_RIGHT
#define STRAIGHT			1
#define TURN_RIGHT			2
#define INITIALIZE_CAMERA	3
#define STOP_AND_PAN		4
#define AUTO_AIM			5
#define AUTONOMOUS_DONE		6

// Define the states for MIDFIELD_DEFENSE
#define DEFENSE_STRAIGHT 	1
#define DEFENSE_TURN_LEFT	2
#define DEFENSE_STRAIGHT_2	3
#define DEFENSE_BACKWARD	4

// Define the states for DIAGONAL_DEFENSE
#define DIAGONAL_TURN_LEFT	1
#define DIAGONAL_STRAIGHT	2
#define DIAGONAL_BACKWARD	3
#define DIAGONAL_STRAIGHT_2	4

/*****************************FUNCTION PROTOTYPES*************************************/
void MORT_autonomous_mode(int mode);
void straight_and_right(void);
void midfield_defense(void);
void diagonal_defense(void);



