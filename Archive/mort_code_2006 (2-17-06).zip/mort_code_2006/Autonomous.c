/*******************************************************************************
* FILE NAME: autonomous.c
*
* DESCRIPTION:
* This file contains autonomous mode functions
*
*******************************************************************************/
#include <stdio.h>
#include "ifi_aliases.h"
#include "ifi_default.h"
#include "ifi_utilities.h"
#include "user_routines.h"
#include "camera.h"
#include "tracking.h"
#include "MORT_AUTONOMOUS.h"

/*************************************************************************************
                                   MORT VARIABLES                                  
*************************************************************************************/
int auton_state;
int first_run = 1;
int counter = 0;
extern int tracking_lock;

void MORT_autonomous_mode( int mode )
{

	switch (mode)
	{
		case STRAIGHT_AND_RIGHT:
			if (first_run)
			{
				printf("Starting STRAIGHT_AND_RIGHT");
				counter = 60;
				auton_state = STRAIGHT;
				first_run = 0;
			}
			straight_and_right( );
			break;

		case MIDFIELD_DEFENSE:
			if (first_run)
			{
				printf("Starting MIDFIELD_DEFENSE");
				counter = 60;
				auton_state = DEFENSE_STRAIGHT;
				first_run = 0;
			}
			midfield_defense();
			break;

		case DIAGONAL_DEFENSE:
			if (first_run)
			{
				printf("Starting DIAGNAL_DEFENSE");
				counter = 60;
				auton_state = DIAGONAL_TURN_LEFT;
				first_run = 0;
			}
			diagonal_defense();
			break;

		default:
			break;
	}

}


//********************************************************************************************************
//							AUTONOMOUS MODE STATE MACHINE	
//********************************************************************************************************
void straight_and_right(void)
{
	Camera_Handler();	// We always want to get new data from camera

	switch (auton_state)
	{
		case STRAIGHT:
			p1_y = 150;
			p1_x = 127;

			printf("GOING STRAIGHT\r\n");

			counter--;
			if (counter == 0)
			{
				counter = 50;
				auton_state = TURN_RIGHT;
			}

			break;

		case TURN_RIGHT:
			p1_y = 127;
			p1_x = 255;

			printf("GOING RIGHT\r\n");

			counter--;
			if (counter == 0)
			{
				auton_state = INITIALIZE_CAMERA;
			}

			break;
		
		case INITIALIZE_CAMERA:
			p1_y = 127;
			p1_x = 127;


			//Camera_Handler() is getting called before the switch

			if( Get_Camera_State() )			// If were initialized... move on
				auton_state = STOP_AND_PAN;

			break;

		case STOP_AND_PAN:
			p1_y = 127;
			p1_x = 127;

			Servo_Track();

			printf("STOP AND PAN... TRACKING LOCK: %d \r\n", tracking_lock);
			
			if (tracking_lock)
				auton_state = AUTO_AIM;

			break;

		case AUTO_AIM:
			p1_y = 127;
			p1_x = 127;
			
			printf("AUTO AIMING...\r\n");

			Servo_Track();

			if (tracking_lock == 1)							// Make sure were locked onto the target before trying to auto-center
			{	
				TURRET_PAN = 127 + (127 - PAN_SERVO);		// Calculate camera offset and add it to TURRET_PAN
			}
			else
			{
				TURRET_PAN = 127;							// If were not tracking, turn off motor
				auton_state = STOP_AND_PAN;
			}
			
			printf(" PAN_SERVO: %d", PAN_SERVO);
			if (PAN_SERVO > 125 && PAN_SERVO < 129)
			{	
				TURRET_PAN = 127;
				auton_state = AUTO_AIM;
			}
				

			// Make sure we dont set the turret speed higher then we want
			if (TURRET_PAN > 127 + TURRET_PAN_SPEED_MAX)
				TURRET_PAN = 127 + TURRET_PAN_SPEED_MAX;
	
			if (TURRET_PAN < 127 - TURRET_PAN_SPEED_MIN)
				TURRET_PAN = 127 - TURRET_PAN_SPEED_MIN;
	
			if (TURRET_TILT > 127 + TURRET_TILT_SPEED_MAX)
				TURRET_TILT = 127 + TURRET_TILT_SPEED_MAX;

			if (TURRET_TILT < 127 - TURRET_TILT_SPEED_MIN)
				TURRET_TILT = 127 - TURRET_TILT_SPEED_MIN;

			break;
		

		case AUTONOMOUS_DONE:
			p1_y = 127;
			p1_x = 127;	
			
			printf("Auton done..");	
	
			break;
	
	}
}

void midfield_defense(void)
{
	switch(auton_state)
	{
		case DEFENSE_STRAIGHT:
			p1_y = 150;
			p1_x = 127;

			printf("GOING STRAIGHT\r\n");

			counter--;
			if (counter == 0)
			{
				counter = 50;
				auton_state = DEFENSE_TURN_LEFT;
			}

			break;

		case DEFENSE_TURN_LEFT:
			p1_y = 127;
			p1_x = 0;

			printf("GOING RIGHT\r\n");

			counter--;
			if (counter == 0)
			{
				auton_state = DEFENSE_STRAIGHT_2;
				counter = 60;
			}

			break;

		case DEFENSE_STRAIGHT_2:
			p1_y = 150;
			p1_x = 127;

			counter--;
			if (counter == 0)
			{
				auton_state = DEFENSE_BACKWARD;
				counter = 60;
			}

			break;

		case DEFENSE_BACKWARD:
			p1_y = 104;
			p1_x = 127;
		
			counter--;
			if (counter == 0)
			{
				auton_state = DEFENSE_STRAIGHT_2;
				counter = 60;
			}
			
			break;
	}
}

void diagonal_defense(void)
{
	switch(auton_state)
	{

		case DIAGONAL_TURN_LEFT:
			p1_y = 127;
			p1_x = 104;

			printf("GOING LEFT 45 DEGREES\r\n");

			counter--;
			if (counter == 0)
			{
				auton_state = DIAGONAL_STRAIGHT;
				counter = 60;
			}

			break;

		case DIAGONAL_STRAIGHT:
			p1_y = 150;
			p1_x = 127;

			printf("GOING DIAGONAL STRAIGHT ALL THE WAY\r\n");

			counter--;
			if (counter == 0)
			{
				counter = 30;
				auton_state = DIAGONAL_BACKWARD;
			}

			break;

		case DIAGONAL_BACKWARD:
			p1_y = 104;
			p1_x = 127;
		
			counter--;
			if (counter == 0)
			{
				auton_state = DIAGONAL_STRAIGHT_2;
				counter = 30;
			}
			
			break;

		case DIAGONAL_STRAIGHT_2:
			p1_y = 150;
			p1_x = 127;

			counter--;
			if (counter == 0)
			{
				auton_state = DIAGONAL_BACKWARD;
				counter = 30;
			}

			break;
	}
}
