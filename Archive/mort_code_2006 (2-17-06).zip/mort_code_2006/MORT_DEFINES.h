/*******************************************************************************
* FILE NAME: MORT_DEFINES.h
*
* DESCRIPTION: 
*  This is the include file that defines all I/O used in the MORT 2005 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
*******************************************************************************/

#ifndef __MORT_DEFINES_h_
#define __MORT_DEFINES_h_

/*************************************************************************************
			                        MORT DEFINES
*************************************************************************************/

/************************************PWM DEFINES*************************************/
// Drive PWM allocations
#define	LEFT_WHEEL						pwm06			// PWM for the left drive motor
#define	RIGHT_WHEEL						pwm07			// PWM for the right drive motor

// End effector PWM allocations
#define TURRET_PAN	 					pwm05			// PWM for turret pan
#define TURRET_TILT	 					pwm04			// PWM for turret tilt

/*******************************CONSTANT DEFINES*************************************/
// End effector Constants
#define Manual_Toggle_Switch		rxdata.oi_swA_byte.bitselect.bit2	// Toggle switch on pot box, PORT 1

// Speeds
#define TURRET_PAN_SPEED_MAX		40					// If the turret spins to fast, the camera can't keep up
#define TURRET_PAN_SPEED_MIN		30					// Motor spins faster one way, so the MAX and MIN values are different
#define TURRET_TILT_SPEED_MAX		22
#define TURRET_TILT_SPEED_MIN		10

// Gradient Sensor
#define TURRET_TILT_POSITION_MAX	1600
#define TURRET_TILT_POSITION_MIN	500			

/********************************OI FEEDBACK******************************************/
#define Camera_Failed_LED			txdata.LED_byte1.bitselect.bit1
#define Camera_Status_LED			txdata.LED_byte1.bitselect.bit0
#define Manual_Toggle_LED			txdata.LED_byte1.bitselect.bit2


/*****************************FUNCTION PROTOTYPES*************************************/
void Update_OI( void );
int ramp_joystick( int value );
void SoftStartWheels( void );



