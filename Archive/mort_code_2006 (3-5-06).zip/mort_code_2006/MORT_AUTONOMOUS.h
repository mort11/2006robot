/*******************************************************************************
* FILE NAME: MORT_AUTONOMOUS.h
*
* DESCRIPTION: 
*  This is the include file that defines all I/O used in the MORT 2005 Robot
*  It contains aliases and function prototypes used in all MORT 'C' routines.
*
*******************************************************************************/
#include "MORT_DEFINES.h"


// Defines for different autonomous modes
#define JUST_SHOOT_SET			1
#define JUST_SHOOT				2
#define OUT_RIGHT_SHOOT			3
#define OUT_RIGHT_SHOOT_SET		4
#define DEFENSE					5


// Define the state for JUST_SHOOT
// No states for this one

// Define the state for JUST_SHOOT_SET
#define SET_ALIGN_TURRET		1
#define SET_SHOOT_BALLS			2

// Define the state for OUT_RIGHT_SHOOT
#define OUT_INITIALIZE_CAMERA 	1
#define OUT_MOVE_OUT_FROM_START	2
#define OUT_DELAY_FOR_TURN		3
#define OUT_TURN_RIGHT			4
#define OUT_SHOOT_BALLS			5

// Define the state for OUT_RIGHT_SHOOT_SET
#define OUT_SET_MOVE_OUT_FROM_START	1
#define OUT_SET_DELAY_FOR_TURN		2
#define OUT_SET_TURN_RIGHT			3
#define OUT_SET_ALIGN_TURRET		4
#define OUT_SET_SHOOT_BALLS			5

// Define the state for DEFENSE
#define DEFENSE_OUT				1
#define DEFENSE_RIGHT			2
#define DEFENSE_STOP			3

/*****************************FUNCTION PROTOTYPES*************************************/
int Get_Auto_Mode( void );
void MORT_autonomous_mode(int mode);
void just_shoot(void);
void just_shoot_set (void);
void out_right_shoot(void);
void out_right_shoot_set(void);
void defense(void);
void turn_off_everything(void);



